
Si vous travaillez sur un syst�me Windows, utilisez l'ex�cutable checker.exe, sinon utilisez checker_unix.
Si aucun ne marche, appelez un enseignant. Nous essaierons de g�n�rer un ex�cutable adapt� � votre syst�me.

Pour le checker_unix pensez � lui donner des droits d'ex�cution (chmod u+x).

checker prend en argument les instances � tester.
cHecker renvoit le nombre de relocalisation de chacune des solutions.

Exemple d'utilisation "checker 1 2 3" v�rifie et affiche le nombre de relocalisation pour les fichier solutions 1_solution.csv 2_solution.csv et 3_solution.csv

Attention l'ex�cutable doit �tre appel� dans le dossier contenant les fichiers d'instance et de solution.